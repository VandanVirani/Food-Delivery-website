import 'package:flutter/material.dart';

class failure extends StatelessWidget {
  const failure({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(child: Text("fail")),
    );
  }
}
