import 'package:dd3/description.dart';
import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';

class MyCart extends StatefulWidget {
  MyCart({Key? key}) : super(key: key);

  @override
  State<MyCart> createState() => _MyCartState();
}

class _MyCartState extends State<MyCart> {
  String place = "";
  String mobile = "";

  @override
  Widget build(BuildContext context) {
    payment_r(price, data, place, mobile) async {
      final response = await http.get(Uri.parse(
          'https://vandanvirani.pythonanywhere.com/api?price=${price}&items=${data}&place=${place}&number=${mobile}'));

      if (response.statusCode == 200) {
        var d = jsonDecode(response.body);

        if (await canLaunchUrl(Uri.parse(d['d']))) {
          await launchUrl(Uri.parse(d['d']));
        } else {
          throw "Could not launch";
        }
      } else {
        throw Exception('Failed to load Entry');
      }
    }

    double tot() {
      double total = 0.0;
      for (int o = 0; o < addToCart.length; o++) {
        total += double.parse(addToCart[o].totalPrice);
      }

      return total;
    }

    Alertbox(BuildContext context) {
      TextEditingController myController = new TextEditingController();
      return showDialog(
          context: context,
          builder: (context) {
            return AlertDialog(
              backgroundColor: Color.fromARGB(166, 255, 255, 255),
              title: Center(
                  child: Text(
                "Total checkout should >= 100 INR",
                style: TextStyle(fontWeight: FontWeight.bold),
              )),
              actions: [
                Center(
                  child: MaterialButton(
                    color: Colors.blue,
                    elevation: 5.0,
                    child: Text(
                      "BACK",
                      style: TextStyle(fontSize: 25),
                    ),
                    onPressed: () {
                      Navigator.of(context).pop(myController.text.toString());
                    },
                    minWidth: 200,
                    height: 50,
                  ),
                )
              ],
            );
          });
    }

    collect_data(BuildContext context) {
      TextEditingController myController2 = new TextEditingController();
      TextEditingController myController3 = new TextEditingController();
      return showDialog(
          context: context,
          builder: (context) {
            return AlertDialog(
              backgroundColor: Colors.white,
              actions: [
                TextField(
                  decoration: InputDecoration(hintText: "Mobile Number"),
                  controller: myController2,
                ),
                TextField(
                  decoration: InputDecoration(hintText: "Place to Deliver"),
                  controller: myController3,
                ),
                SizedBox(
                  height: 5,
                ),
                Center(
                  child: MaterialButton(
                    color: Colors.blue,
                    elevation: 5.0,
                    child: Text(
                      "SUBMIT",
                      style: TextStyle(fontSize: 25),
                    ),
                    onPressed: () {
                      setState(() {
                        place = myController3.text;
                        mobile = myController2.text;
                      });
                      Navigator.of(context).pop();
                    },
                    minWidth: 200,
                    height: 50,
                  ),
                )
              ],
            );
          });
    }

    return_cart_list(id_to_remove, name, quantity, price, image_add) {
      return Container(
        decoration: BoxDecoration(
            color: Colors.white, borderRadius: BorderRadius.circular(20)),
        child: Row(
          children: [
            Container(
              width: 120,
              height: 120,
              decoration: BoxDecoration(),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(14),
                child: Image.asset(
                  "${image_add}",
                  fit: BoxFit.fill,
                ),
              ),
            ),
            Expanded(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Text(
                        "${name}",
                        style: TextStyle(
                          shadows: <Shadow>[
                            Shadow(
                              offset: Offset(1, 1),
                              blurRadius: 3.0,
                              color: Color.fromARGB(255, 0, 0, 0),
                            ),
                          ],
                          fontFamily: 'Peralta',
                          color: Colors.black,
                          fontSize: 20,
                        ),
                      ),
                      SizedBox(
                        height: 5,
                      ),
                      Text(
                        "Qty : ${quantity}",
                        style: TextStyle(
                            shadows: <Shadow>[
                              Shadow(
                                offset: Offset(1, 1),
                                blurRadius: 3.0,
                                color: Color.fromARGB(255, 0, 0, 0),
                              ),
                            ],
                            color: Colors.black,
                            fontSize: 20,
                            fontWeight: FontWeight.bold),
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Text(
                        "₹ ${price}",
                        style: TextStyle(
                            shadows: <Shadow>[
                              Shadow(
                                offset: Offset(1, 1),
                                blurRadius: 3.0,
                                color: Color.fromARGB(255, 255, 0, 0),
                              ),
                            ],
                            color: Colors.black,
                            fontSize: 25,
                            fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            SizedBox(
              width: 10,
            ),
            IconButton(
              icon: Icon(Icons.delete),
              onPressed: () {
                for (int o = 0; o < addToCart.length; o++) {
                  if (addToCart[o].id == id_to_remove) {
                    setState(() {
                      addToCart.removeAt(o);
                    });
                    Navigator.pop(context);
                    Navigator.pushNamed(context, "/cart");
                    break;
                  }
                }
              },
            ),
            SizedBox(
              width: 5,
            )
          ],
        ),
      );
    }

    return Scaffold(
        appBar: AppBar(
          centerTitle: true,
          leadingWidth: 80,
          backgroundColor: Color.fromARGB(255, 11, 128, 224),
          leading: Builder(
            builder: (BuildContext context) {
              return IconButton(
                icon: const Icon(Icons.arrow_back),
                onPressed: () {
                  Navigator.pop(context);
                },
                tooltip: MaterialLocalizations.of(context).openAppDrawerTooltip,
              );
            },
          ),
          title: Text("Cart",
              style: TextStyle(
                shadows: <Shadow>[
                  Shadow(
                    offset: Offset(1.5, 1.5),
                    blurRadius: 3.0,
                    color: Color.fromARGB(255, 0, 0, 0),
                  ),
                ],
                fontFamily: "CinZel",
                color: Colors.white,
                fontSize: 30,
              )),
        ),
        body: Container(
          color: Colors.grey[200],
          child: Stack(
            children: [
              ListView.builder(
                itemCount: addToCart.length,
                itemBuilder: (context, position) {
                  return ListTile(
                    title: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Column(
                          children: [
                            SizedBox(
                              height: 10,
                            ),
                            return_cart_list(
                                addToCart[position].id,
                                addToCart[position].nameOfFood,
                                addToCart[position].quantity,
                                addToCart[position].totalPrice,
                                addToCart[position].name_address),
                          ],
                        )),
                  );
                },
              ),
              Column(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      FloatingActionButton.extended(
                        onPressed: () {
                          if (tot() >= 100) {
                            List data = [];
                            for (int k = 0; k < addToCart.length; k++) {
                              data.add(addToCart[k].nameOfFood +
                                  " " +
                                  addToCart[k].quantity.toString());
                            }

                            collect_data(context).then((value) {
                              if (mobile.length == 10 && place.length >= 5) {
                                payment_r(tot(), data, place, mobile);
                              } else {
                                return ScaffoldMessenger.of(context)
                                    .showSnackBar(SnackBar(
                                        duration: const Duration(seconds: 2),
                                        content: Container(
                                          padding: EdgeInsets.all(15),
                                          height: 100,
                                          decoration: BoxDecoration(
                                              color: Colors.red,
                                              borderRadius: BorderRadius.all(
                                                  Radius.circular(10))),
                                          child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              Text(
                                                "Oh crap!",
                                                style: TextStyle(
                                                    fontFamily: "Peralta",
                                                    fontSize: 17,
                                                    color: Colors.white),
                                              ),
                                              Text(
                                                "Enter num properly or place should have more than 5 words",
                                                style: TextStyle(
                                                    fontFamily: "Peralta",
                                                    fontSize: 13,
                                                    color: Colors.white),
                                              ),
                                            ],
                                          ),
                                        )));
                              }
                            });
                          } else
                            Alertbox(context);
                        },
                        label: Text("Pay ${tot()}"),
                        icon: Icon(Icons.currency_rupee),
                        backgroundColor: Colors.blue[800],
                      ),
                      SizedBox(
                        width: 30,
                      )
                    ],
                  ),
                  SizedBox(
                    height: 30,
                  )
                ],
              ),
            ],
          ),
        ));
  }

  // @override
  // void dispose() {
  //   _razorpay.clear();
  //   super.dispose();
  // }
}
