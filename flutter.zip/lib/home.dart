import 'dart:math';

import 'package:flutter/material.dart';
import 'description.dart';
import 'package:scroll_snap_list/scroll_snap_list.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';
import 'package:flutter_custom_clippers/flutter_custom_clippers.dart';

class homePage extends StatelessWidget {
  List<dynamic> stall1 = [];
  List<dynamic> stall2 = [];
  List<dynamic> stall3 = [];
  List<dynamic> stall4 = [];
  List<dynamic> stall5 = [];
  List<dynamic> stall6 = [];
  final item_controller = PageController();
  final combo_controller = PageController();
  @override
  Widget build(BuildContext context) {
    createAlertDialog(y, BuildContext context) {
      TextEditingController myController = new TextEditingController(text: '1');
      return showDialog(
          context: context,
          builder: (context) {
            return AlertDialog(
              backgroundColor: Colors.white,
              title: Center(
                  child: Text(
                "Quantity",
                style: TextStyle(fontWeight: FontWeight.bold),
              )),
              content: TextField(
                textAlign: TextAlign.center,
                keyboardType: TextInputType.phone,
                controller: myController,
              ),
              actions: [
                Center(
                  child: MaterialButton(
                    color: Colors.blue,
                    elevation: 5.0,
                    child: Text(
                      "Add to Cart",
                      style: TextStyle(fontSize: 25),
                    ),
                    onPressed: () {
                      Navigator.of(context).pop(myController.text.toString());
                      addToCart.add(AddToCart(
                          id: "${y.id}",
                          nameOfFood: "${y.nameOfFood}",
                          quantity: myController.text.toString(),
                          totalPrice:
                              "${double.parse(y.price) * double.parse(myController.text.toString())}",
                          name_address: y.image_name));
                      myController.clear();
                    },
                    minWidth: 200,
                    height: 50,
                  ),
                )
              ],
            );
          });
    }

    Widget HoriList(x, index) {
      TextEditingController myController = new TextEditingController();

      return Padding(
        padding: const EdgeInsets.fromLTRB(15, 10, 15, 20),
        child: Container(
          width: 260,
          height: 300,
          decoration: BoxDecoration(
              boxShadow: [
                BoxShadow(
                  color: Color.fromARGB(255, 201, 132, 29).withOpacity(0.9),
                  spreadRadius: 9,
                  blurRadius: 9,
                  offset: Offset(0, 5), // changes position of shadow
                ),
              ],
              color: Colors.white,
              borderRadius: BorderRadius.all(Radius.circular(12))),
          child: ClipRRect(
            borderRadius: BorderRadius.all(Radius.circular(20)),
            child:
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Image.asset(
                "assests/SpecialCombo/${index}.png",
              ),
              SizedBox(
                height: 10,
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    x[index].nameOfFood,
                    style: TextStyle(
                      fontFamily: 'Peralta',
                      color: Colors.black,
                      fontSize: 20,
                    ),
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          SizedBox(
                            height: 5,
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              SizedBox(
                                width: 10,
                              ),
                              Container(
                                decoration: BoxDecoration(
                                    color: Colors.grey[400],
                                    borderRadius: BorderRadius.circular(12)),
                                child: Text(
                                  "  ${x[index].d1}  ",
                                  style: TextStyle(
                                    color: Colors.black,
                                    fontSize: 10,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                              SizedBox(
                                width: 7,
                              ),
                              Container(
                                decoration: BoxDecoration(
                                    color: Colors.grey[400],
                                    borderRadius: BorderRadius.circular(12)),
                                child: Text(
                                  "  ${x[index].d2}  ",
                                  style: TextStyle(
                                    color: Colors.black,
                                    fontSize: 10,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          SizedBox(
                            width: 15,
                          ),
                          Text(
                            "₹ ${x[index].price}",
                            style: TextStyle(
                                color: Colors.black,
                                fontSize: 25,
                                fontWeight: FontWeight.bold),
                          ),
                        ],
                      ),
                      Row(
                        children: [
                          ElevatedButton(
                            style: ButtonStyle(
                                backgroundColor:
                                    MaterialStateProperty.all<Color>(
                                        Color.fromARGB(255, 255, 0, 0))),
                            onPressed: () {
                              createAlertDialog(x[index], context);
                            },
                            child: Text(
                              "ADD TO CART",
                              style: TextStyle(
                                  fontSize: 15, fontWeight: FontWeight.bold),
                            ),
                          ),
                          SizedBox(
                            width: 15,
                          )
                        ],
                      ),
                    ],
                  ),
                ],
              ),
              SizedBox(
                height: 10,
              ),
            ]),
          ),
        ),
      );
    }

    Widget VerticalList_stall(x, index) {
      return Padding(
        padding: const EdgeInsets.fromLTRB(10, 30, 15, 20),
        child: Container(
          decoration: BoxDecoration(
              boxShadow: [
                BoxShadow(
                  color: Colors.grey.withOpacity(0.5),
                  spreadRadius: 5,
                  blurRadius: 7,
                  offset: Offset(0, 3), // changes position of shadow
                ),
              ],
              color: Colors.white,
              borderRadius: BorderRadius.all(Radius.circular(12))),
          child: Padding(
            padding: const EdgeInsets.all(15.0),
            child: ClipRRect(
              // decoration: BoxDecoration(
              //   color: Colors.grey.shade500.withOpacity(0.6),
              // ),

              child: Column(
                children: [
                  ClipRRect(
                    borderRadius: const BorderRadius.all(Radius.circular(10)),
                    child: Image.asset(
                      "${x[index].image_name}",
                      width: 220,
                      height: 200,
                    ),
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Expanded(
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Text(
                              x[index].nameOfFood,
                              style: TextStyle(
                                fontFamily: 'Peralta',
                                color: Colors.black,
                                fontSize: 20,
                              ),
                            ),
                            SizedBox(
                              height: 5,
                            ),
                            Text(
                              x[index].nameOfStall,
                              style: TextStyle(
                                color: Colors.black,
                                fontSize: 15,
                              ),
                            ),
                            SizedBox(
                              height: 10,
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  "₹ ${x[index].price}",
                                  style: TextStyle(
                                      color: Colors.black,
                                      fontSize: 25,
                                      fontWeight: FontWeight.bold),
                                ),
                                SizedBox(
                                  width: 20,
                                ),
                                ElevatedButton(
                                  style: ButtonStyle(
                                      backgroundColor:
                                          MaterialStateProperty.all<Color>(
                                              Color.fromARGB(255, 255, 0, 0))),
                                  onPressed: () {
                                    createAlertDialog(x[index], context);
                                  },
                                  child: Text(
                                    "ADD TO CART",
                                    style: TextStyle(
                                        fontSize: 15,
                                        fontWeight: FontWeight.bold),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      );
    }

    return Scaffold(
        body: Stack(
      children: [
        CustomScrollView(
          slivers: [
            SliverAppBar(
              pinned: true,
              //floating: true,
              bottom: PreferredSize(
                preferredSize: Size.fromHeight(10),
                child: Container(
                  height: 60,
                  alignment: Alignment.center,
                  width: double.maxFinite,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(50),
                          topRight: Radius.circular(50)),
                      shape: BoxShape.rectangle,
                      color: Colors.grey[100]),
                  child: Text("Delivery Dude's",
                      style: TextStyle(
                        shadows: <Shadow>[
                          Shadow(
                            offset: Offset(1.5, 1.5),
                            blurRadius: 3.0,
                            color: Color.fromARGB(255, 0, 0, 0),
                          ),
                        ],
                        fontFamily: "CinZel",
                        color: Color.fromARGB(255, 255, 17, 0),
                        fontSize: 35,
                      )),
                ),
              ),
              backgroundColor: Colors.grey[100],
              flexibleSpace: FlexibleSpaceBar(
                background: Image.asset(
                  "assests/food_back2.jpg",
                  fit: BoxFit.fill,
                ),
                expandedTitleScale: 1.2,
                collapseMode: CollapseMode.pin,
                centerTitle: true,
              ),
              centerTitle: true,
              expandedHeight: MediaQuery.of(context).size.height * 0.25,
            ),
            SliverList(
                delegate: SliverChildListDelegate([
              Container(
                // decoration: BoxDecoration(
                //     image: DecorationImage(
                //         image: AssetImage("assests/rectangle3.png"),
                //         fit: BoxFit.fill,
                //         colorFilter: ColorFilter.mode(
                //             Colors.black.withOpacity(0.4), BlendMode.dstATop))),
                decoration: BoxDecoration(color: Colors.grey[100]),
                child: Container(
                  child: Column(children: [
                    Padding(
                      padding: const EdgeInsets.fromLTRB(10, 10, 10, 0),
                      child: Container(
                        width: double.infinity,
                        height: 400,
                        child: ListView.builder(
                            controller: item_controller,
                            scrollDirection: Axis.horizontal,
                            physics: const AlwaysScrollableScrollPhysics(),
                            itemCount: 18,
                            itemBuilder: (BuildContext context, int index) {
                              return Row(
                                children: [
                                  VerticalList_stall(collection, index),
                                  SizedBox(
                                    width: 10,
                                  ),
                                ],
                              );
                            }),
                      ),
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    SmoothPageIndicator(
                        controller: item_controller,
                        count: 14,
                        axisDirection: Axis.horizontal,
                        effect: ScrollingDotsEffect(
                          activeStrokeWidth: 2.6,
                          activeDotScale: 1.3,
                          maxVisibleDots: 5,
                          radius: 8,
                          spacing: 10,
                          dotHeight: 12,
                          dotWidth: 12,
                        )),
                    SizedBox(
                      height: 20,
                    ),
                    ClipPath(
                      clipper: WaveClipperTwo(reverse: true, flip: true),
                      child: Container(
                        color: Colors.orange.shade300,
                        child: Column(
                          children: [
                            SizedBox(
                              height: 100,
                            ),
                            Text(
                              "Special Combo",
                              style: TextStyle(
                                  fontFamily: "CinZel",
                                  color: Colors.white,
                                  fontSize: 30,
                                  fontWeight: FontWeight.bold),
                            ),
                            SizedBox(
                              height: 20,
                            ),
                            Padding(
                              padding: const EdgeInsets.fromLTRB(10, 10, 10, 0),
                              child: Container(
                                width: double.infinity,
                                height: 300,
                                child: ListView.builder(
                                    controller: combo_controller,
                                    scrollDirection: Axis.horizontal,
                                    physics:
                                        const AlwaysScrollableScrollPhysics(),
                                    itemCount: 4,
                                    itemBuilder:
                                        (BuildContext context, int index) {
                                      return Row(
                                        children: [
                                          HoriList(collectionHori, index),
                                          SizedBox(
                                            width: 10,
                                          ),
                                        ],
                                      );
                                    }),
                              ),
                            ),
                            SizedBox(
                              height: 20,
                            ),
                            SmoothPageIndicator(
                                controller: combo_controller,
                                count: 3,
                                axisDirection: Axis.horizontal,
                                effect: ScrollingDotsEffect(
                                  activeDotColor: Colors.green.shade700,
                                  dotColor: Colors.white,
                                  activeStrokeWidth: 2.6,
                                  activeDotScale: 1.3,
                                  maxVisibleDots: 5,
                                  radius: 8,
                                  spacing: 10,
                                  dotHeight: 12,
                                  dotWidth: 12,
                                )),
                            SizedBox(
                              height: 60,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ]),
                ),
              )
            ]))
          ],
        ),
        Column(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                FloatingActionButton.extended(
                  onPressed: () {
                    Navigator.pushNamed(context, '/cart');
                  },
                  label: Text("CART"),
                  icon: Icon(Icons.shopping_cart_checkout),
                  backgroundColor: Colors.blue[800],
                ),
                SizedBox(
                  width: 20,
                )
              ],
            ),
            SizedBox(
              height: 20,
            ),
          ],
        )
      ],
    ));
  }
}

// import 'dart:math';

// import 'package:flutter/material.dart';
// import 'description.dart';
// import 'package:scroll_snap_list/scroll_snap_list.dart';
// import 'package:smooth_page_indicator/smooth_page_indicator.dart';

// class homePage extends StatelessWidget {
//   List<dynamic> stall1 = [];
//   List<dynamic> stall2 = [];
//   List<dynamic> stall3 = [];
//   List<dynamic> stall4 = [];
//   List<dynamic> stall5 = [];
//   List<dynamic> stall6 = [];
//   final item_controller = PageController();
//   final combo_controller = PageController();
//   @override
//   Widget build(BuildContext context) {
//     createAlertDialog(y, BuildContext context) {
//       TextEditingController myController = new TextEditingController();
//       return showDialog(
//           context: context,
//           builder: (context) {
//             return AlertDialog(
//               backgroundColor: Color.fromARGB(166, 255, 255, 255),
//               title: Center(
//                   child: Text(
//                 "Quantity",
//                 style: TextStyle(fontWeight: FontWeight.bold),
//               )),
//               content: TextField(
//                 textAlign: TextAlign.center,
//                 keyboardType: TextInputType.phone,
//                 controller: myController,
//               ),
//               actions: [
//                 Center(
//                   child: MaterialButton(
//                     color: Colors.blue,
//                     elevation: 5.0,
//                     child: Text(
//                       "Add to Cart",
//                       style: TextStyle(fontSize: 25),
//                     ),
//                     onPressed: () {
//                       Navigator.of(context).pop(myController.text.toString());
//                       addToCart.add(AddToCart(
//                           id: "${y.id}",
//                           nameOfFood: "${y.nameOfFood}",
//                           quantity: myController.text.toString(),
//                           totalPrice:
//                               "${double.parse(y.price) * double.parse(myController.text.toString())}",
//                           name_address: y.image_name));
//                     },
//                     minWidth: 200,
//                     height: 50,
//                   ),
//                 )
//               ],
//             );
//           });
//     }

//     Widget HoriList(x, index) {
//       TextEditingController myController = new TextEditingController();
//       return Padding(
//         padding: const EdgeInsets.fromLTRB(15, 10, 15, 20),
//         child: Container(
//           width: 260,
//           height: 300,
//           decoration: BoxDecoration(
//               boxShadow: [
//                 BoxShadow(
//                   color: Colors.grey.withOpacity(0.5),
//                   spreadRadius: 5,
//                   blurRadius: 7,
//                   offset: Offset(0, 3), // changes position of shadow
//                 ),
//               ],
//               color: Colors.white,
//               borderRadius: BorderRadius.all(Radius.circular(12))),
//           // decoration: BoxDecoration(
//           //     boxShadow: const [
//           //       BoxShadow(
//           //           color: Colors.black54, // shadow color
//           //           blurRadius: 20, // shadow radius
//           //           offset: Offset(5, 10), // shadow offset
//           //           spreadRadius:
//           //               0.1, // The amount the box should be inflated prior to applying the blur
//           //           blurStyle: BlurStyle.normal // set blur style
//           //           ),
//           //     ],
//           //     color: Colors.white,
//           //     border: Border.all(color: Colors.black, width: 3),
//           //     borderRadius: BorderRadius.all(Radius.circular(20))),
//           child: ClipRRect(
//             borderRadius: BorderRadius.all(Radius.circular(20)),
//             child:
//                 Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
//               Image.asset(
//                 "assests/SpecialCombo/${index}.png",
//               ),
//               SizedBox(
//                 height: 10,
//               ),
//               Column(
//                 crossAxisAlignment: CrossAxisAlignment.center,
//                 mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                 children: [
//                   Text(
//                     x[index].nameOfFood,
//                     style: TextStyle(
//                       fontFamily: 'Peralta',
//                       color: Colors.black,
//                       fontSize: 20,
//                     ),
//                   ),
//                   Row(
//                     mainAxisAlignment: MainAxisAlignment.center,
//                     children: [
//                       Column(
//                         crossAxisAlignment: CrossAxisAlignment.start,
//                         children: [
//                           SizedBox(
//                             height: 5,
//                           ),
//                           Row(
//                             mainAxisAlignment: MainAxisAlignment.start,
//                             children: [
//                               SizedBox(
//                                 width: 10,
//                               ),
//                               Container(
//                                 decoration: BoxDecoration(
//                                     color: Colors.grey[400],
//                                     borderRadius: BorderRadius.circular(12)),
//                                 child: Text(
//                                   "  ${x[index].d1}  ",
//                                   style: TextStyle(
//                                     color: Colors.black,
//                                     fontSize: 10,
//                                     fontWeight: FontWeight.bold,
//                                   ),
//                                 ),
//                               ),
//                               SizedBox(
//                                 width: 7,
//                               ),
//                               Container(
//                                 decoration: BoxDecoration(
//                                     color: Colors.grey[400],
//                                     borderRadius: BorderRadius.circular(12)),
//                                 child: Text(
//                                   "  ${x[index].d2}  ",
//                                   style: TextStyle(
//                                     color: Colors.black,
//                                     fontSize: 10,
//                                     fontWeight: FontWeight.bold,
//                                   ),
//                                 ),
//                               ),
//                             ],
//                           ),
//                         ],
//                       ),
//                     ],
//                   ),
//                   SizedBox(
//                     height: 20,
//                   ),
//                   Row(
//                     mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                     children: [
//                       // Text(
//                       //               "₹ ${x[index].price}",
//                       //               style: TextStyle(
//                       //                   color: Colors.black,
//                       //                   fontSize: 25,
//                       //                   fontWeight: FontWeight.bold),
//                       //             ),
//                       Row(
//                         children: [
//                           SizedBox(
//                             width: 15,
//                           ),
//                           Text(
//                             "₹ 999",
//                             style: TextStyle(
//                                 color: Colors.black,
//                                 fontSize: 25,
//                                 fontWeight: FontWeight.bold),
//                           ),
//                         ],
//                       ),
//                       Row(
//                         children: [
//                           ElevatedButton(
//                             style: ButtonStyle(
//                                 backgroundColor:
//                                     MaterialStateProperty.all<Color>(
//                                         Color.fromARGB(255, 255, 0, 0))),
//                             onPressed: () {
//                               createAlertDialog(x[index], context);
//                             },
//                             child: Text(
//                               "ADD TO CART",
//                               style: TextStyle(
//                                   fontSize: 15, fontWeight: FontWeight.bold),
//                             ),
//                           ),
//                           SizedBox(
//                             width: 15,
//                           )
//                         ],
//                       ),
//                     ],
//                   ),
//                 ],
//               ),
//               SizedBox(
//                 height: 10,
//               ),
//             ]),
//           ),
//         ),
//       );
//     }

//     Widget VerticalList_stall(x, index) {
//       return Padding(
//         padding: const EdgeInsets.fromLTRB(10, 10, 15, 20),
//         child: Container(
//           decoration: BoxDecoration(
//               boxShadow: [
//                 BoxShadow(
//                   color: Colors.grey.withOpacity(0.5),
//                   spreadRadius: 5,
//                   blurRadius: 7,
//                   offset: Offset(0, 3), // changes position of shadow
//                 ),
//               ],
//               color: Colors.white,
//               borderRadius: BorderRadius.all(Radius.circular(12))),
//           child: Padding(
//             padding: const EdgeInsets.all(15.0),
//             child: ClipRRect(
//               // decoration: BoxDecoration(
//               //   color: Colors.grey.shade500.withOpacity(0.6),
//               // ),

//               child: Column(
//                 children: [
//                   ClipRRect(
//                     borderRadius: const BorderRadius.all(Radius.circular(10)),
//                     child: Image.asset(
//                       "${x[index].image_name}",
//                       width: 220,
//                       height: 200,
//                     ),
//                   ),
//                   SizedBox(
//                     height: 10,
//                   ),
//                   Expanded(
//                     child: Row(
//                       mainAxisAlignment: MainAxisAlignment.center,
//                       children: [
//                         Column(
//                           crossAxisAlignment: CrossAxisAlignment.center,
//                           mainAxisAlignment: MainAxisAlignment.start,
//                           children: [
//                             Text(
//                               x[index].nameOfFood,
//                               style: TextStyle(
//                                 fontFamily: 'Peralta',
//                                 color: Colors.black,
//                                 fontSize: 20,
//                               ),
//                             ),
//                             SizedBox(
//                               height: 5,
//                             ),
//                             Text(
//                               x[index].nameOfStall,
//                               style: TextStyle(
//                                 color: Colors.black,
//                                 fontSize: 15,
//                               ),
//                             ),
//                             SizedBox(
//                               height: 10,
//                             ),
//                             Row(
//                               mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                               children: [
//                                 Text(
//                                   "₹ ${x[index].price}",
//                                   style: TextStyle(
//                                       color: Colors.black,
//                                       fontSize: 25,
//                                       fontWeight: FontWeight.bold),
//                                 ),
//                                 SizedBox(
//                                   width: 20,
//                                 ),
//                                 ElevatedButton(
//                                   style: ButtonStyle(
//                                       backgroundColor:
//                                           MaterialStateProperty.all<Color>(
//                                               Color.fromARGB(255, 255, 0, 0))),
//                                   onPressed: () {
//                                     createAlertDialog(x[index], context);
//                                   },
//                                   child: Text(
//                                     "ADD TO CART",
//                                     style: TextStyle(
//                                         fontSize: 15,
//                                         fontWeight: FontWeight.bold),
//                                   ),
//                                 ),
//                               ],
//                             ),
//                           ],
//                         ),
//                       ],
//                     ),
//                   ),
//                 ],
//               ),
//             ),
//           ),
//         ),
//       );
//     }

//     return Scaffold(
//         body: Stack(
//       children: [
//         CustomScrollView(
//           slivers: [
//             SliverAppBar(
//               pinned: true,
//               //floating: true,
//               bottom: PreferredSize(
//                 preferredSize: Size.fromHeight(50),
//                 child: Container(
//                   height: 60,
//                   alignment: Alignment.center,
//                   width: double.maxFinite,
//                   decoration: BoxDecoration(
//                       borderRadius: BorderRadius.only(
//                           topLeft: Radius.circular(50),
//                           topRight: Radius.circular(50)),
//                       shape: BoxShape.rectangle,
//                       color: Colors.grey[100]),
//                   child: Text("Delivery Dude's",
//                       style: TextStyle(
//                         shadows: <Shadow>[
//                           Shadow(
//                             offset: Offset(1.5, 1.5),
//                             blurRadius: 3.0,
//                             color: Color.fromARGB(255, 0, 0, 0),
//                           ),
//                         ],
//                         fontFamily: "CinZel",
//                         color: Color.fromARGB(255, 255, 17, 0),
//                         fontSize: 35,
//                       )),
//                 ),
//               ),
//               backgroundColor: Colors.white,
//               flexibleSpace: FlexibleSpaceBar(
//                 background: Image.asset(
//                   "assests/food_back2.jpg",
//                   fit: BoxFit.fill,
//                 ),
//                 expandedTitleScale: 1.2,
//                 collapseMode: CollapseMode.pin,
//                 centerTitle: true,
//               ),
//               centerTitle: true,
//               expandedHeight: MediaQuery.of(context).size.height * 0.25,
//             ),
//             SliverList(
//                 delegate: SliverChildListDelegate([
//               Container(
//                 // decoration: BoxDecoration(
//                 //     image: DecorationImage(
//                 //         image: AssetImage("assests/rectangle3.png"),
//                 //         fit: BoxFit.fill,
//                 //         colorFilter: ColorFilter.mode(
//                 //             Colors.black.withOpacity(0.4), BlendMode.dstATop))),
//                 decoration: BoxDecoration(color: Colors.grey[100]),
//                 child: Container(
//                   child: Column(children: [
//                     Padding(
//                       padding: const EdgeInsets.fromLTRB(10, 10, 10, 0),
//                       child: Container(
//                         width: double.infinity,
//                         height: 370,
//                         child: ListView.builder(
//                             controller: item_controller,
//                             scrollDirection: Axis.horizontal,
//                             physics: const AlwaysScrollableScrollPhysics(),
//                             itemCount: 18,
//                             itemBuilder: (BuildContext context, int index) {
//                               return Row(
//                                 children: [
//                                   VerticalList_stall(collection, index),
//                                   SizedBox(
//                                     width: 10,
//                                   ),
//                                 ],
//                               );
//                             }),
//                       ),
//                     ),
//                     SizedBox(
//                       height: 20,
//                     ),
//                     SmoothPageIndicator(
//                         controller: item_controller,
//                         count: 14,
//                         axisDirection: Axis.horizontal,
//                         effect: ScrollingDotsEffect(
//                           activeStrokeWidth: 2.6,
//                           activeDotScale: 1.3,
//                           maxVisibleDots: 5,
//                           radius: 8,
//                           spacing: 10,
//                           dotHeight: 12,
//                           dotWidth: 12,
//                         )),
//                     SizedBox(
//                       height: 20,
//                     ),
//                     Text(
//                       "Special Combo",
//                       style: TextStyle(
//                         shadows: <Shadow>[
//                           Shadow(
//                             offset: Offset(2.0, 2.0),
//                             blurRadius: 2.5,
//                             color: Color.fromARGB(255, 0, 0, 0),
//                           ),
//                         ],
//                         fontFamily: "CinZel",
//                         color: Colors.grey.shade900,
//                         fontSize: 30,
//                       ),
//                     ),
//                     SizedBox(
//                       height: 20,
//                     ),
//                     Padding(
//                       padding: const EdgeInsets.fromLTRB(10, 10, 10, 0),
//                       child: Container(
//                         width: double.infinity,
//                         height: 300,
//                         child: ListView.builder(
//                             controller: combo_controller,
//                             scrollDirection: Axis.horizontal,
//                             physics: const AlwaysScrollableScrollPhysics(),
//                             itemCount: 4,
//                             itemBuilder: (BuildContext context, int index) {
//                               return Row(
//                                 children: [
//                                   HoriList(collectionHori, index),
//                                   SizedBox(
//                                     width: 10,
//                                   ),
//                                 ],
//                               );
//                             }),
//                       ),
//                     ),
//                     SizedBox(
//                       height: 20,
//                     ),

//                     SmoothPageIndicator(
//                         controller: combo_controller,
//                         count: 3,
//                         axisDirection: Axis.horizontal,
//                         effect: ScrollingDotsEffect(
//                           activeStrokeWidth: 2.6,
//                           activeDotScale: 1.3,
//                           maxVisibleDots: 5,
//                           radius: 8,
//                           spacing: 10,
//                           dotHeight: 12,
//                           dotWidth: 12,
//                         )),

//                     SizedBox(
//                       height: 60,
//                     ),
//                   ]),
//                 ),
//               )
//             ]))
//           ],
//         ),
//         Column(
//           mainAxisAlignment: MainAxisAlignment.end,
//           children: [
//             Row(
//               mainAxisAlignment: MainAxisAlignment.end,
//               children: [
//                 FloatingActionButton.extended(
//                   onPressed: () {
//                     Navigator.pushNamed(context, '/cart');
//                   },
//                   label: Text("CART"),
//                   icon: Icon(Icons.shopping_cart_checkout),
//                   backgroundColor: Colors.blue[800],
//                 ),
//                 SizedBox(
//                   width: 20,
//                 )
//               ],
//             ),
//             SizedBox(
//               height: 20,
//             ),
//           ],
//         )
//       ],
//     ));
//   }
// }
