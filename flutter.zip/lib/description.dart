// front page  vertical scroll list
class FastFoodDescription {
  String id;
  String nameOfStall;
  String nameOfFood;
  String image_name;
  String price;

  FastFoodDescription({
    required this.id,
    required this.nameOfStall,
    required this.nameOfFood,
    required this.price,
    required this.image_name,
  });
}

List<FastFoodDescription> collection = [
  FastFoodDescription(
      id: "1",
      nameOfStall: "Ravi's stall",
      nameOfFood: "Italian Pizza",
      price: "129",
      image_name: "assests/Images/1.png"),
  FastFoodDescription(
      id: "2",
      nameOfStall: "Parth's stall",
      nameOfFood: "Cold Coco",
      price: "39",
      image_name: "assests/Images/2.png"),
  FastFoodDescription(
      id: "3",
      nameOfStall: "Kajal's stall",
      nameOfFood: "Cheese Frankie",
      price: "49",
      image_name: "assests/Images/3.png"),
  FastFoodDescription(
      id: "4",
      nameOfStall: "Akshay's stall",
      nameOfFood: "Burger",
      price: "139",
      image_name: "assests/Images/4.png"),
  FastFoodDescription(
      id: "5",
      nameOfStall: "Vandan's stall",
      nameOfFood: "Coco",
      price: "49",
      image_name: "assests/Images/5.png"),
  FastFoodDescription(
      id: "6",
      nameOfStall: "Adarsh's stall",
      nameOfFood: "Cheese Burger",
      price: "89",
      image_name: "assests/Images/6.png"),
  FastFoodDescription(
      id: "7",
      nameOfStall: "Krishna's stall",
      nameOfFood: "Italian Pizza",
      price: "229",
      image_name: "assests/Images/7.png"),
  FastFoodDescription(
      id: "8",
      nameOfStall: "Radhe's stall",
      nameOfFood: "Lolipop",
      price: "369",
      image_name: "assests/Images/8.png"),
  FastFoodDescription(
      id: "9",
      nameOfStall: "Govind's stall",
      nameOfFood: "Grill sandwich",
      price: "39",
      image_name: "assests/Images/9.png"),
  FastFoodDescription(
      id: "10",
      nameOfStall: "Kala's stall",
      nameOfFood: "Italian HotDog",
      price: "229",
      image_name: "assests/Images/10.png"),
  FastFoodDescription(
      id: "11",
      nameOfStall: "Nandan's stall",
      nameOfFood: "Aloopuri",
      price: "99",
      image_name: "assests/Images/11.png"),
  FastFoodDescription(
      id: "12",
      nameOfStall: "Madhuram's stall",
      nameOfFood: "Chees Sandwich",
      price: "199",
      image_name: "assests/Images/12.png"),
  FastFoodDescription(
      id: "13",
      nameOfStall: "Govind's stall",
      nameOfFood: "Italian Pizza",
      price: "99",
      image_name: "assests/Images/13.png"),
  FastFoodDescription(
      id: "14",
      nameOfStall: "Patel's stall",
      nameOfFood: "Pasta",
      price: "329",
      image_name: "assests/Images/14.png"),
  FastFoodDescription(
      id: "15",
      nameOfStall: "Virani's stall",
      nameOfFood: "pop ring",
      price: "99",
      image_name: "assests/Images/15.png"),
  FastFoodDescription(
      id: "16",
      nameOfStall: "Jiyani's stall",
      nameOfFood: "FrechFries",
      price: "229",
      image_name: "assests/Images/16.png"),
  FastFoodDescription(
      id: "17",
      nameOfStall: "Chiman's stall",
      nameOfFood: "Gola",
      price: "99",
      image_name: "assests/Images/17.png"),
  FastFoodDescription(
      id: "18",
      nameOfStall: "Bansi's stall",
      nameOfFood: "Manchurium",
      price: "199",
      image_name: "assests/Images/18.png"),
];
//////////////////////////////////////////////
// front page horizontal scroll list

class FastFoodDescriptionHori {
  String price;
  String id;
  String nameOfFood;
  String d1;
  String d2;
  String image_name;

  FastFoodDescriptionHori(
      {required this.price,
      required this.id,
      required this.nameOfFood,
      required this.d1,
      required this.d2,
      required this.image_name});
}

List<FastFoodDescriptionHori> collectionHori = [
  FastFoodDescriptionHori(
      price: "99",
      id: "19",
      nameOfFood: "Rapchik Combo",
      d1: "Frankie",
      d2: "Mocktail",
      image_name: "assests/SpecialCombo/0.png"),
  FastFoodDescriptionHori(
      price: "9",
      id: "20",
      nameOfFood: "DhapChik Combo",
      d1: "Coco",
      d2: "Soup",
      image_name: "assests/SpecialCombo/1.png"),
  FastFoodDescriptionHori(
      price: "900",
      id: "21",
      nameOfFood: "Bapchik Combo",
      d1: "Frankie",
      d2: "Maggi",
      image_name: "assests/SpecialCombo/2.png"),
  FastFoodDescriptionHori(
      price: "999",
      id: "22",
      nameOfFood: "tapchik Combo",
      d1: "Frankie",
      d2: "Maggi",
      image_name: "assests/SpecialCombo/3.png"),
];

// // add to cart

class AddToCart {
  String id;
  String nameOfFood;
  String quantity;
  String totalPrice;
  String name_address;
  AddToCart(
      {required this.id,
      required this.nameOfFood,
      required this.quantity,
      required this.totalPrice,
      required this.name_address});
}

List<AddToCart> addToCart = [];

